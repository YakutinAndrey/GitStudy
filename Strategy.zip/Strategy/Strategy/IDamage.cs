﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Strategy
{
    interface IDamage
    {
        void Kick();
    }
}
